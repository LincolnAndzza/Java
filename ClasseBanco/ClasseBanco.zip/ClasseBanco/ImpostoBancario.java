public interface ImpostoBancario
{
    public double impostoRenda(double valor);
    
    public double cpmf(double valor);
    
    public double iof(double valor);
}
